
export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <section className="bg-green-700 text-white py-20 px-6 text-center">
        <h1 className="text-5xl font-bold mb-4">Lovemark Enterprise</h1>

        <p className="text-xl max-w-2xl mx-auto">
          Supporting businesses through flexible installment payments.
        </p>

        <div className="mt-8 flex justify-center gap-4 flex-wrap">
          <a
            href="https://wa.me/233246184283"
            className="bg-white text-green-700 px-6 py-3 rounded-2xl shadow-lg font-semibold"
          >
            Chat on WhatsApp
          </a>

          <a
            href="tel:+233506850457"
            className="border border-white px-6 py-3 rounded-2xl font-semibold"
          >
            Call Us
          </a>
        </div>
      </section>

      <section className="py-16 px-6 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-6">About Us</h2>

        <p className="text-lg leading-8">
          Lovemark Enterprise helps traders, workers, and entrepreneurs access goods through trusted installment payment plans.
        </p>
      </section>

      <footer className="bg-green-700 text-white text-center py-6">
        <p>© 2026 Lovemark Enterprise</p>
      </footer>
    </div>
  )
}
