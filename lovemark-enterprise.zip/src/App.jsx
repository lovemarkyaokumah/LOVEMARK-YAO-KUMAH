export default function App() {
  const products = [
    { name: 'Phone Installment Plan', price: 'GHS 500/month' },
    { name: 'TV Installment Plan', price: 'GHS 350/month' },
    { name: 'Fridge Installment Plan', price: 'GHS 400/month' },
  ]

  return (
    <div style={{ fontFamily: 'Arial', padding: 20 }}>
      <h1>Lovemark Enterprise</h1>
      <p>Installment Payment Facilitator</p>

      <h2>Services</h2>
      <ul>
        <li>Phones & Electronics</li>
        <li>Home Appliances</li>
        <li>Flexible Payment Plans</li>
      </ul>

      <h2>Packages</h2>
      {products.map((p, i) => (
        <div key={i} style={{ border: '1px solid #ccc', padding: 10, margin: 10 }}>
          <h3>{p.name}</h3>
          <p>{p.price}</p>
        </div>
      ))}

      <h2>Contact</h2>
      <p>Call: 0506850457</p>
      <p>WhatsApp: 0246184283</p>
    </div>
  )
}
